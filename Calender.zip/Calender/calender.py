import calendar
year = 2024
month =  6 #June
x = calendar.month(year,month)
print(x)
